package com.estore.domain.common

import java.util.Date;

class BaseDomainEntity {
	
	Date createdDate;

}
